public class MultithreadingDemo implements Runnable{

    public void run(){
        try{System.out.println("threads"+threads.currentthread().getld()+"ïs running by java");
        
}
catch (Exception e)
{
    System.out.println("exception is caught here");
}}
}
class Multithread{
    public static void main(String[] args)
    {
        int n=8;
        for(int i =0 ;i<=n;i++)
        {
            thread object = new Thread(new MutltithreadingDemo());
            object.start();
            
        }
    }
}